console.log("This is Ajax");
let reg=/harry/;
reg=/harry/g;
reg=/harry/i;
console.log(reg)
console.log(reg.source)