import chalk from 'chalk';
console.log(chalk.blue('Hello world!'));
