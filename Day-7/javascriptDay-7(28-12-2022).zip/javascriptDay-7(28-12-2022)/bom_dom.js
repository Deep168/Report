//BOM
let a= document;
 a=document.all;
a=document.body;
 a=document.forms[0];
 console.log(a);
// DOM
 alert("hello")
 var data=prompt("Enter your age")
 console.log(data);
 if(confirm("Do you want to really Delete?")){
    console.log("Deleted")
 }else{
    console.log("Cancelled")}
    function func1(){
        print()
    }
    setTimeout(function(){
        alert("Welcome")
    },2000) 

    setInterval(function(){
         document.getElementById('p3').innerHTML=(new Date()).toLocaleString();
    },2000)


 