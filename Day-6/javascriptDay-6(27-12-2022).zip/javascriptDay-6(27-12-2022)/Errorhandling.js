
// setTimeout(()=>{
//   console.log('rahul')  
// }, 1000);
// try{
//     console.log('rahul')
// }
// catch(err){
//     console.log('error'+ err)
// }
// setTimeout= ()=>{
// console
// }


// Error Object
// try{
//     let age=prompt("Enter your age")
//     age= Number.ParseInt(age)
//     if(age>150){
// throw new ReferenceError("not true")
// }
// }catch(error){
//     console.log(error.name)
//     console.log(error.message)
//     console.log(error.stack)
// }
// console.log('script ios still running')

//finally
try{
    let a=0;
    console.log('programmme Run successfully')
  
}
catch(err){
    console.log('This is an error')
    cxonsole.log(p)
}finally{
    console.log("I am good boy")
}